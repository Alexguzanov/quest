package com.example.quest;

import java.util.ArrayList;

public class Player {
    private String name;
    private Location currentLocation;
    private ArrayList<Item> inventory;

    public Player(String name, Location startingLocation) {
        this.name = name;
        this.currentLocation = startingLocation;
        this.inventory = new ArrayList<Item>();
    }

    public String getName() {
        return name;
    }

    public Location getCurrentLocation() {
        return currentLocation;
    }

    public void setCurrentLocation(Location location) {
        this.currentLocation = location;
    }

    public ArrayList<Item> getInventory() {
        return inventory;
    }

    public void addItemToInventory(Item item) {
        inventory.add(item);
    }

}