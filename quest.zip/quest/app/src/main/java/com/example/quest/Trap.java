package com.example.quest;

public class Trap {
    private String description; // описание ловушки
    private String effect; // последствия для игрока

    public Trap(String description, String effect) {
        this.description = description;
        this.effect = effect;
    }

    public String getDescription() {
        return description;
    }

    public String getEffect() {
        return effect;
    }
}