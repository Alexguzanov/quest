package com.example.quest;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;


import java.io.Console;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

//using System;
//using System.Collections.Generic;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        Location startingLocation = new Location("Начальное место", "Вы находитесь в начальной локации.", new ArrayList<Direction>(), new ArrayList<Item>());
        Location location1 = new Location("Локация 1", "Вы находитесь в локации 1.", new ArrayList<Direction>(), new ArrayList<Item>());
        Location location2 = new Location("Локация 2", "Вы находитесь в локации 2.", new ArrayList<Direction>(), new ArrayList<Item>());
        Location location3 = new Location("Локация 3", "Вы находитесь в локации 3.", new ArrayList<Direction>(), new ArrayList<Item>());


        Direction startToLocation1 = new Direction(startingLocation, location1, "Вы можете пойти в локацию 1.");
        Direction location1ToLocation2 = new Direction(location1, location2, "Вы можете пойти в локацию 2.");
        Direction location1ToLocation3 = new Direction(location1, location3, "Вы можете пойти в локацию 3.");
        Direction location2ToLocation1 = new Direction(location2, location1, "Вы можете пойти в локацию 1.");
        Direction location3ToLocation1 = new Direction(location3, location1, "Вы можете пойти в локацию 1.");


        startingLocation.getDirections().add(startToLocation1);
        location1.getDirections().add(location1ToLocation2);
        location1.getDirections().add(location1ToLocation3);
        location2.getDirections().add(location2ToLocation1);
        location3.getDirections().add(location3ToLocation1);


        Item item1 = new Item("Меч", "Острый меч.", 5);
        Item item2 = new Item("Щит", "Крепкий щит.", 10);


        location1.getItems().add(item1);
        location2.getItems().add(item2);


        Trap trap1 = new Trap("Ловушка 1", "Вы потеряли половину здоровья.");
        Trap trap2 = new Trap("Ловушка 2", "Вы потеряли все здоровье и проиграли.");


        List<Trap> traps = new ArrayList<Trap>();
        traps.add(trap1);
        traps.add(trap2);
        Castle castle = new Castle(new List<Location> { startingLocation, location1, location2, location3 }, traps);


        Player player = new Player("Игрок 1", startingLocation);

        //игровой цикл
        while (true)
        {
            System.out.println(player.getCurrentLocation().getDescription());
            System.out.println("Вы можете пойти в следующие локации: ");

            for (Direction direction in player.getCurrentLocation().getDirections())
            {
                System.out.println(direction.getDescription();
                if (direction != player.getCurrentLocation().getDirections())
                {
                    System.out.println(", ");
                }
            }

            System.out.println();
            System.out.println();
            System.out.println("Введите направление: ");
            String input = scanner.next();

            // Находим выбранное направление
            Direction selectedDirection = null;

            for (Direction direction in player.getCurrentLocation().getDirections())
            {
                if (input() == direction.getName().ToLower())
                {
                    selectedDirection = direction;
                    break;
                }
            }

            if (selectedDirection == null)
            {
                System.out.println("Неверное направление! Попробуйте еще раз.");
                continue;
            }


            player.setCurrentLocation(selectedDirection.getToLocation());


            System.out.println(player.getCurrentLocation().getDescription());


            for (Item item in player.getCurrentLocation().getItems())
            {
                System.out.println("Вы нашли предмет: {item.getName()}. {item.getDescription()}");

                System.out.println("Хотите взять его? (да/нет) ");
                String answer = ;

                if (answer == "да")
                {

                    player.addItemToInventory(item);
                    System.out.println($"Вы добавили {item.getName()} в свой инвентарь.");
                }
            }


            for (Trap trap in castle.getTraps())
            {
                if (player.getCurrentLocation().getItems()) {
                    System.out.println(trap.getDescription());
                    System.out.println(trap.getEffect());
                }
            }
        }
    }
}