package com.example.quest;

import java.util.ArrayList;

public class Castle {
    private ArrayList<Location> locations;
    private ArrayList<Trap> traps;

    public Castle(ArrayList<Location> locations, ArrayList<Trap> traps) {
        this.locations = locations;
        this.traps = traps;
    }

    public ArrayList<Location> getLocations() {
        return locations;
    }

    public ArrayList<Trap> getTraps() {
        return traps;
    }
}
