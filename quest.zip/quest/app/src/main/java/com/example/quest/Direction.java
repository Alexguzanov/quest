package com.example.quest;

public class Direction {
    private Location fromLocation;
    private Location toLocation;
    private String description;
    private String name;

    public Direction(Location fromLocation, Location toLocation, String description) {
        this.fromLocation = fromLocation;
        this.toLocation = toLocation;
        this.description = description;
    }

    public Location getFromLocation() {
        return fromLocation;
    }

    public Location getToLocation() {
        return toLocation;
    }

    public String getDescription() {
        return description;
    }

    public String getName() {
        return name;
    }
}